#pragma once

namespace Esp
{
    void render() noexcept;
}
