#pragma once

namespace Reportbot
{
    void run() noexcept;
    void reset() noexcept;
}
