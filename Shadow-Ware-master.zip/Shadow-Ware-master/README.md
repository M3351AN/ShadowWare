我生活在 China - China 永远的No.1

Shadow Ware开源作者 发呆 私人定制\商业合作\BUG反馈 + QQ 2476159893

此Shadow Ware 版本为中文版 有不懂的可以加群 787528015

GUI以及其他功能除了PULL添加的全都是手写的！请尊重劳动成果！

如果觉得可以就帮忙赞助一下，谢谢各位

我的打算:
添加Rage Bot AntiAim 皮肤搜索等等
因为我是学生所以一周更新一次
字体下载:https://shadowware.lanzous.com/icgcg7i

![Image text](http://ripgod.club/attachments/vumwmgnj-fhml85gy6y-d99-jpg.303/?hash=88350d159b78b4f6c1a8362838f01488)

/***********************************/分割线

我是这个项目的合作者nosexynomoney QQ381106559

协助发呆发展项目

未来会为这个项目加入LUA系统

ShadowWare Forever
